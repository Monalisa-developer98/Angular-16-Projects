import {
  Swiper
} from "./chunk-3M2Y47KF.js";
import "./chunk-WKYGNSYM.js";
export {
  Swiper,
  Swiper as default
};
//# sourceMappingURL=swiper.js.map
