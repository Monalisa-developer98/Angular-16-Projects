import {
  Swiper
} from "./chunk-3OEMFA6B.js";
import "./chunk-ASLTLD6L.js";
export {
  Swiper,
  Swiper as default
};
//# sourceMappingURL=swiper.js.map
