import { Component, OnInit } from '@angular/core';
import { GlobalService } from '../../services/global.service';

@Component({
  selector: 'app-event-list',
  templateUrl: './event-list.component.html',
  styleUrl: './event-list.component.css'
})
export class EventListComponent implements OnInit {
  eventResponse: any;
  eventData: any;
  imageUrl = 'https://api.trlkrosaki.com';

  selectedYear: string = '';
  search: string = '';
  years: string[] = ['2022', '2023', '2024', '2019'];
  noDataFound: boolean | undefined;

  constructor(private eventService: GlobalService){}

  ngOnInit(): void {
    this.getEventList();
  }

 async getEventList(){
  const params = {
    language: 'en',
      pageIndex: 1,
      search: this.search,
      pageSize: 12,
      year: this.selectedYear
  }
  try{
    this.eventResponse = await this.eventService.getEvents(params);
    this.eventData = this.eventResponse.data;
    this.noDataFound = this.eventData.length === 0;
    // console.log(this.eventData);

  } catch(error){
    console.log('Error:', JSON.stringify(error));
    this.noDataFound = true;
  }
 }

onSearchChange() {
  this.validateSearch();
  this.getEventList();
}

validateSearch(): void {
  const regex = /^[a-zA-Z0-9 ]*$/;
  if (!regex.test(this.search)) {
    this.search = '';
  }
}

filterByYear() {
  this.getEventList();
}

}
